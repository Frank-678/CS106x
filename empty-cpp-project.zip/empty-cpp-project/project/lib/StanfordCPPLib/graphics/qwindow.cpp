///*
// * File: qwindow.cpp
// * -----------------
// */

//#include "qwindow.h"

//QWindow::QWindow(double width, double height, bool visible) {
//    _window = new QApplication(0, nullptr);
//    _window.exec();
//}

//virtual QWindow::~QWindow() {
//    // empty
//}

//std::string QWindow::getTitle() const {

//}

//void QWindow::setTitle(const std::string& title) {

//}
