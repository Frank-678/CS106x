#include "optional.h"

/* The one Nothing object. */
nothing_t Nothing;
